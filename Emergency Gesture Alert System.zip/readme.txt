#1 run code
.venv310/Scripts/Activate.ps1

#2 run code 
python HelpMe.py